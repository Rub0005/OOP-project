import javax.swing.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Company company = new Company("JTravels", new ArrayList<>());
        company.addTrip("boen215", "Moscow", "Novgorod", "14/10/2022",
                "15/10/2022", company);

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MainGUI mainGUI = new MainGUI(company);
                mainGUI.setVisible(true);
            }
        });
    }

}
