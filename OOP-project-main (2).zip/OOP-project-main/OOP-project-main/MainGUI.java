import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MainGUI extends JFrame {
    private Company company;

    public MainGUI(Company company) {
        this.company = company;

        // Set up the JFrame
        setTitle("Travel Company Application");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create components
        JLabel titleLabel = new JLabel("Welcome to " + company.getName());
        titleLabel.setBounds(200, 20, 200, 30);
        add(titleLabel);

        JButton addTripButton = new JButton("Add Trip");
        addTripButton.setBounds(50, 70, 100, 30);
        addTripButton.addActionListener(new ActionListener() {
            class AddTripDialog {
                public AddTripDialog(MainGUI mainGUI, Company company) {

                }

                public void setVisible(boolean b) {

                }
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                // Open a dialog to add a trip
                AddTripDialog dialog = new AddTripDialog(MainGUI.this, company);
                dialog.setVisible(true);
            }
        });
        add(addTripButton);

        JButton viewTripsButton = new JButton("View Trips");
        viewTripsButton.setBounds(200, 70, 100, 30);
        viewTripsButton.addActionListener(new ActionListener() {
            class TripListDialog {
                public TripListDialog(MainGUI mainGUI, Company company) {

                }

                public void setVisible(boolean b) {

                }
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                // Show a list of trips
                TripListDialog dialog = new TripListDialog(MainGUI.this, company);
                dialog.setVisible(true);
            }
        });
        add(viewTripsButton);

        // Set layout
        setLayout(null);
    }
}
